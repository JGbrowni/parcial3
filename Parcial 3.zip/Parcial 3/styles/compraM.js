const cartInfo = document.querySelector('.cart-product')
const rowProduct = document.querySelector('.row-product')

//Lista de los contenedores de productos//

const productsList = document.querySelector('container-items')

let allProducts = []




productsList.addEventListener('click', e=>{
    if(e.target.classList.contains('btn-add-cart')){
        const product = e.target.parentElement

        console.log(product.querySelector('h2').textContent)
    }
})